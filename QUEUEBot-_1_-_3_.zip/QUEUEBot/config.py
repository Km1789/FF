settings = {
	'token': 'Nzg5MTU1MTM1Mzc2MzI2Njk2.X9t7_g.eq9cDtPZjpMl4MH5ePer_Ng5MVo',
    'bot': 'Queue',
    'id': 789155135376326696,
    'prefix': '!'
}
